#include "hello_world.h"

bool print_hello_world(bool print)
{
if (print)
{
cout << "Hello World from hello_world.cpp" << endl;
}
else
{
cout << "No Hello World from hello_world.cpp" << endl;
}
cout << "Hi world" << endl;
return true;
}