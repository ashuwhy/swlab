#include "hello_world.h"

int main()
{
cout << "Hello World from main.cpp" << endl;
cout << print_hello_world(true);
return 0;
}