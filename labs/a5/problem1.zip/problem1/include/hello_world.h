#include <iostream>
using namespace std;
bool print_hello_world(bool);