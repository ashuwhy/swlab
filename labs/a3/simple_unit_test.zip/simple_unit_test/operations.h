#include <iostream>
using namespace std;

class Operations{

public:
    int add(int a, int b)
    {
        return a + b;
    }

    int multiply(int a, int b)
    {
        return a * b;
    }
};