#include "operations.h"

int main(){
    Operations operations;
    std::cout << operations.add(5, 3) << std::endl;
    std::cout << operations.multiply(5, 3) << std::endl;
    
    return 0;
}